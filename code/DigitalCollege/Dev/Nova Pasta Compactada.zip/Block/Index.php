<?php
namespace DigitalCollege\Dev\Block;
class Index extends \Magento\Framework\View\Element\Template
{

}
